# Whyte Design System

Design tokens, CSS and React components shared across Whyte products. The reference page
(`index.html`, deployed at https://whyte-design-system-syntaxion.vercel.app) shows every foundation and
component with its specs.

## What's in it

| Path | What |
| --- | --- |
| `styles.css` | The one file to link. Imports the tokens and the component CSS. |
| `tokens/` | Colour, typography, spacing and effects as CSS custom properties. The source of truth. |
| `themes/app.css` | Optional. Inter throughout, for apps and internal tools. |
| `components.css` | Styles for the components. Class names match the reference page. |
| `src/` | React components (TypeScript), built to `dist/`. |
| `fonts/`, `logos/` | Delight and Inter, and the Whyte logos: wordmark, stag, the stacked lock-up and the horizontal lock-up (stag beside wordmark), each in charcoal and white. |

## Using it in an app

Install it from GitHub at a commit or tag (it builds on install). This repo is private, so a build
server needs read access to it; otherwise install a packed copy made with `npm pack`.

```bash
npm install github:dbateson/whyte-design-system#<commit-or-tag>
```

Load the CSS once, at the root of the app (for Next.js, in `app/layout.tsx`):

```ts
import "@whyte/design-system/styles.css";
import "@whyte/design-system/themes/app.css"; // apps and internal tools only: Inter throughout
```

### Typefaces

Delight is the brand face for display, headings and lead (20px and above) on brand surfaces: the
website, campaigns, anything customer-facing. Inter sets everything at 18px and below.

- **Figures are always Inter**, at any size, through the `--font-data` token. Delight has no tabular
  figures, so numbers set in it can't line up in columns or hold still as they change.
- **Apps use Inter throughout.** Link `themes/app.css` after `styles.css`; it points
  `--font-display` at Inter, so every heading style switches with it. The Whyte wordmark carries the
  brand.

Then use the components:

```tsx
import { MetricCard } from "@whyte/design-system";

<MetricCard
  title="Social reach"
  source="Instagram · Facebook"
  value="287.0k"
  delta={{ value: -2.1 }}           // colour shows better or worse, not up or down
  trend={[10.5, 9.8, 11.2, 13.5, 12.8]}
/>
```

Components come from two entries:

- `@whyte/design-system`: everything without state. These render in React Server Components; event
  props such as `onClick` or `onSort` need a client component, as usual.
- `@whyte/design-system/client`: interactive components that hold state (`SideNav`, `Tabs`,
  `SegmentedControl`, `DateRangePicker`, `AppMenuProvider`, `AppMenuButton`, `AccountMenu`, `LineChart`, `LineChartCard`, `ColumnChart`,
  `ColumnChartCard`, `DonutChart`, `FilterLayout`, `FilterToggle`, `CodeBlock`, `Dialog`, `ChatComposer`). This entry is marked `"use client"`.

## Components

| Component | Reference | Notes |
| --- | --- | --- |
| `Button` | `.btn-p`, `.btn-s`, `.btn-t` | `variant`: primary, secondary, tertiary. `size`: standard (40px), small (32px). `icon` after the label. `href` renders a link. |
| `IconButton` | `.iconbtn` | `label` is required: it is the accessible name. `size`: standard (32px), small (24px). |
| `TextField` | `.fld`, `.input` | `label`, `help`, `error`, `size`. Wires up the label, `aria-describedby` and `aria-invalid`. |
| `Select` | `.selwrap`, `.select` | As `TextField`; pass `<option>`s as children. Native menu. |
| `TextArea` | `.fld.prose`, `.textarea` | As `TextField`, up to `--width-6` wide. |
| `Checkbox`, `Radio` | `.chk` | `label`, `description` (a smaller, lighter line under it, read as the description), `disabled`, and any input prop (`checked`, `defaultChecked`, `name`, `value`, `onChange`). `className` goes on the `<label>`. |
| `Switch` | `.tgl` | A setting that applies at once: a native checkbox with `role="switch"`. Props as `Checkbox`. In a submitted form, use a checkbox. |
| `Fieldset` | `.fieldset`, `.chkgroup` | Groups checkboxes, radios or switches: `legend`, `help`, `error` (wired with `aria-describedby`, the field's error look), `columns` (1, 2 or 3; stacks below 640px). |
| `Table` and parts | `.dtable` | `TableHeader` takes `numeric` and `sort` (`ascending`, `descending`, `none`) with `onSort`. `TableCell` takes `numeric`. Every table insets its first and last columns 12px. `hover` turns on row hover: only for interactive rows or very wide tables. |
| `Status` | `.status` | An 8px dot and its word. `tone`: success, warning, error, neutral. |
| `MetricCard` | `.metric` | `title`, `value` (formatted), `source`, `delta` `{ value, unit, goodWhen, label, precision }`, `trend`, `href`. `unit` is `"%"` (default) or `"pt"` for changes in a percentage. |
| `CardGrid`, `GridItem` | `.cardgrid` | Rows of cards on the 12-column grid. `GridItem` takes `span` (3, 4, 6, 8, 9, 12). Cards in a row match heights; spans narrow to halves below 960px of grid width and full width below 600px. Under a four-across row use quarters: a chart with a side panel is 9 + 3. |
| `Panel` | `.panelcard` | A card for content that isn't a chart: a form, details, a list. `title` (body at 500, cap-height aligned like every card title), `description`, `actions` (top right), `headingLevel`. A `<section>` named by its title. |
| `Stack`, `Inline` | `.ds-stack`, `.ds-inline` | Token spacing between blocks. `Stack` `gap`: small (16px, form fields), standard (24px), large (32px, sections); `as` div, form, section or fieldset. `Inline`: a wrapping row, `gap` standard (12px, buttons) or small (8px, badges). |
| `TopBar` | `.topbar` | The app's top bar: `brand` (the horizontal lock-up, 36px), `product`, `actions` (such as a `Badge`), `menu` (an `AppMenuButton`, shown below 1024px). Pass it to `AppShell` as `topbar`, inside `AppMenuProvider`. |
| `AccountMenu` (client) | `.acct` | The signed-in person: `name`, `detail`, `email`, `initials`, `items` (`label`, `href` or `onSelect`, `separated`), `placement` (`up` at the foot of the side menu, `down` in a top bar). A menu button with full keyboard support. |
| `Badge` | `.badge` | A small grey label with a dot: a data source, or a page-wide status. `tone`: neutral, success, warning, error. |
| `AppShell` | `.appshell` | The app frame: `sidebar` on the left, the page in `<main>`. Below 1024px the sidebar becomes a top bar. |
| `PageHeader` | `.pagehead` | The page name as the `h1`, with optional `actions` (such as a date range picker) on the right, a `breadcrumb` above and a `description` below. |
| `Breadcrumb` | `.crumbs` | Where a deep page sits: `items` (`label`, `href`; a level with no `href` shows as text), the last is the current page. |
| `Pagination` | `.pager` | `page`, `pageCount`, and `hrefFor(page)` when the page is in the URL or `onChange(page)` in place. Long runs collapse to “…”. |
| `DataTable` | `.datatable` | A large table whose sort and page live in the URL: `columns` (`key`, `header`, `cell`, `numeric`, `sortable`), the page's `rows`, `total`, `page`, `pageSize`, `sort`, `sortHref`, `pageHref`, `actions` (Download CSV, `FilterToggle`), `summary` (what the rows add up to), `noun`, `empty`. |
| `FilterLayout`, `FilterToggle` (client) | `.filterlayout` | A data page's body: `children` (the `DataTable`) beside `filters` in a 280px panel pinned on the right, with `count` and `clear`. `FilterToggle`, in the table's actions, hides and shows it; below 1100px it slides in over the page. |
| `FilterBar` | `.filterbar` | A row of small labelled `Select`s that filter the whole page, with an optional `clear` link. |
| `DescriptionList` | `.dlist` | Facts in a row, term above detail: a metric's definition, source and update time. |
| `EmptyState` | `.empty` | `title`, a line of text, an optional `action` and `icon`. For no results, nothing yet, not tracked. |
| `Alert` | `.alert` | `tone`: info, success, warning, error. `title`, `children`, `action` (a small button or link), `onDismiss` (shows the small close button, "Dismiss"). Errors are `role="alert"`, the rest `role="status"`. |
| `Spinner` | `.spinner` | `size`: small (16px), standard (24px), large (32px). `label` (default "Loading"), `inverse` inside a primary button. Slows with reduced motion. |
| `Dialog` (client) | `.dialog` | A modal on the native `<dialog>`: `open`, `onClose` (Escape and the close button), `title`, `description`, `children`, `actions` (right-aligned footer), `size` (standard 480px, wide 720px). Focus moves in, and back to the opener on close. |
| `Prose` | `.richtext` | Styles rich text rendered from Markdown: paragraphs, h2–h4, lists, quotes, code, links, rules and tables (the data table's look, scrolling sideways when wide). `as`: div or article. |
| `CodeBlock` (client) | `.codeblock` | Monospace on `--surface-card` with a Copy button that reads "Copied" for two seconds: `code`, `label` (caption and accessible name), `copyLabel`, `wrap`. For a public key, or an API key shown once. |
| `ChatThread`, `ChatMessage` | `.chatthread`, `.chatmsg` | The assistant's conversation. `ChatThread` (`label`) is a polite log that scrolls. `ChatMessage`: `role` (user: a bubble on the right; assistant: full width, as prose), `author`, `meta` (time, sources), `status` (streaming, error), `attachments`. |
| `ChatAttachment` | `.chatfile` | A file a message made: `name`, `detail` ("CSV · 12 KB"), `href`, `download`, `renderLink`. |
| `TicketThread`, `TicketMessage`, `TicketEvent` | `.tthread`, `.tmsg`, `.tevent` | A support ticket's history, top to bottom. `TicketThread` (`label`) is a named list. `TicketMessage`: `from` (customer: on `--surface-card`; agent, assistant: a hairline-bordered panel), `author`, `meta` (time, channel, delivery), `internal` (warning tint and an "Internal note" badge), `footer`; body set as prose. `TicketEvent`: a change (status, assignment) as one small line, with `meta` for when. |
| `ChatComposer` (client) | `.composer` | `value`, `onChange(value)`, `onSubmit()`, `label` (visually hidden), `placeholder`, `hint`, `busy` with `onStop` (Send becomes Stop), `disabled`, `maxRows` (default 8). Grows with its text; Enter sends, Shift+Enter starts a line; blank messages can't be sent. |
| `SideNav` (client) | `.appnav` | `brand` (the horizontal lock-up, which spans the menu; leave out under a `TopBar`), `items` (each may have `children`: sub-pages one level deep; the section row then opens and closes them rather than linking) (`href`, `label`, `current`), optional `footer`. `sections`: `"open"` (default) starts every section open; `"current"` opens only the current page's section, for menus too long to fit. `renderLink` lets you pass your router's link. Collapses to a menu button below 1024px. |
| `Tabs` (client) | `.tabs` | `items` (`id`, `label`, `content`) and a `label` for screen readers. Arrow keys, Home and End move between tabs. |
| `DateRangePicker` (client) | `.drp` | `value` (`start`, `end` as `YYYY-MM-DD`), `presets`, `presetId`, `max`, `min`, `onChange(range, presetId?)`. A preset applies at once; a custom range is two clicks and Apply. |
| `SegmentedControl` (client) | `.segmented` | Switches how the same content shows: `options` (`value`, `label`), `value`, `onChange`, `label`. Small (32px) only. A radio group: arrow keys, Home and End. |
| `ChartCard` | `.chartcard` | Frames one chart: `title`, optional `subtitle`, optional `actions` (controls, top right). A `<figure>` named by its title. |
| `LineChart` (client) | `.linechart` | Change over time. `dates` (`YYYY-MM-DD`, one per point), `granularity` (`day`, `week`, `month`), `series` (`id`, `label`, `values`, `muted`), `format`, `zeroBased`. Hover or arrow keys read every series at a date; a Chart \| Table control gives the values as a table. `view` and `onViewChange` control it; `viewControl={false}` hides the built-in control. |
| `LineChartCard` (client) | `.chartcard` | A `LineChart` in a `ChartCard`, with the Chart \| Table control in the card's header. Takes `title`, `subtitle` and the `LineChart` props. Use this for charts in cards. |
| `ColumnChart`, `ColumnChartCard` (client) | `.columnchart` | An amount across a few categories or periods: `items` (`label`, `value`), `format`, `categoryLabel` (the table's first column). One blue series, columns at most 24px wide with a 4px rounded top. Hover or arrow keys read a column; the card's Chart \| Table control gives the values. |
| `DonutChart` (client) | `.donut` | How one whole splits into two to six parts: `items`, `format`, `totalLabel`. Past six, the smallest fold into "Other". The total sits in the middle; the legend gives every part its figure and share. Put it in a `ChartCard`. To rank or compare close parts, use `BarList`. |
| `BarList` | `.barlist` | Ranked or ordered parts: a name, its printed figure, an 8px bar. `ordinal` steps ordered stages (funnels) from dark to light blue. An item's `href` makes its name a link (to filter the page to it); `current` marks the one chosen. |
| Value formatting | | `formatValue(value, format)`, `formatTick`, `niceTicks`, `compactNumber`. A `ValueFormat` is plain data: `style` (`number`, `currency`, `percent`), `compact`, `digits`, `symbol`. |
| Icons | | `ChevronDownIcon`, `ChevronUpDownIcon`, `ChevronLeftIcon`, `ChevronRightIcon`, `ArrowRightIcon`, `ErrorIcon`, `InfoIcon`, `SuccessIcon`, `WarningIcon`, `FileIcon`, `DownloadIcon`, `CalendarIcon`, `MenuIcon`, `CloseIcon`. |
| Dates | | `addDays`, `addMonths`, `compareDates`, `daysInRange`, `formatRange`, `orderedRange`, `parseISODate`, `toISODate`: calendar-date helpers in UTC. |

### Charts

Charts speak one colour wherever they can, using the `--data-*` tokens in `tokens/colors.css`:

- **One series** is the chart blue (`--data-accent`, the same as `--data-1`), with a light wash under a single line.
- **One series that matters among others** (Whyte against competitors): mark the others `muted`.
  They draw in pale blue (`--data-muted`) under the blue line.
- **Several equal series** take the categorical palette `--data-1` to `--data-8`, in that order,
  never cycled. The brand's own hues read as grey and can't tell series apart, so this is a
  validated data palette; re-validate before changing it. Two or more series always get a legend,
  and every line chart has a table view.
- **Ordered stages** (funnel steps, tiers) use the ordinal ramp `--data-ordinal-1` to `-4`.
- **Parts of one whole** in a doughnut take `--data-1` onwards in order, up to six, with a 2px gap.
  Doughnuts are for the split at a glance; ranking or close comparison is a bar list.
- Never put two value axes on one chart: two measures make two charts.

On a dark surface, put the class `ondark` on an ancestor; buttons and icon buttons switch to their
on-dark styling.

## Developing

```bash
npm install          # install dependencies (also builds dist/)
npm run build        # bundle with tsup, then write type declarations with tsc
npm run typecheck    # type-check
npm test             # run the tests (Vitest)
npm run dev          # rebuild on change
```

To try changes in the dashboard before releasing, run `npm link` here and
`npm link @whyte/design-system` in the dashboard.

### Releasing

Bump `version` in `package.json`, merge to `main`, then tag the merge commit (`v0.2.0`) and push the
tag. Consumers move to the new tag in their `package.json`.

Renaming or removing a token, class name or component prop is a breaking change. Call it out in the
pull request with a migration note.
